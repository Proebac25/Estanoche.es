import React from 'react';

function AvisoLegal() {
  return (
    <div className="container" style={{ padding: '2rem 1rem', maxWidth: '800px', margin: '0 auto' }}>
      <h1 style={{ fontSize: '2rem', marginBottom: '1.5rem', textAlign: 'center' }}>Aviso Legal</h1>
      
      <h2 style={{ fontSize: '1.5rem', margin: '1.5rem 0 1rem' }}>1. Identificaci�n del titular</h2>
      <p>En cumplimiento del art�culo 10 de la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Informaci�n y Comercio Electr�nico (LSSI-CE), se informa:</p>
      <ul style={{ marginLeft: '1.5rem', marginBottom: '1rem' }}>
        <li><strong>Titular:</strong> Miguel Garc�a Dur�n (Proebac25)</li>
        <li><strong>NIF:</strong> [INSERTE NIF REAL]</li>
        <li><strong>Domicilio:</strong> [INSERTE DOMICILIO REAL], Jerez de la Frontera, C�diz, Espa�a</li>
        <li><strong>Email:</strong> proebac25@estanoche.es</li>
        <li><strong>Tel�fono:</strong> [INSERTE TEL�FONO]</li>
      </ul>
      
      <h2 style={{ fontSize: '1.5rem', margin: '1.5rem 0 1rem' }}>2. Objeto</h2>
      <p>EstaNoche.es es una plataforma web progresiva (PWA) que centraliza informaci�n sobre eventos y ocio nocturno en Andaluc�a. No realiza contrataci�n directa ni intermediaci�n comercial.</p>
      
      <h2 style={{ fontSize: '1.5rem', margin: '1.5rem 0 1rem' }}>3. Propiedad intelectual</h2>
      <p>Todos los contenidos (textos, im�genes, marcas) son propiedad de Proebac25 o sus licenciantes. Queda prohibida su reproducci�n sin autorizaci�n expresa.</p>
      
      <h2 style={{ fontSize: '1.5rem', margin: '1.5rem 0 1rem' }}>4. Responsabilidad</h2>
      <p>Proebac25 no se hace responsable de los contenidos publicados por terceros (creadores de eventos). Se reserva el derecho a modificar o eliminar contenido inapropiado.</p>
      
      <h2 style={{ fontSize: '1.5rem', margin: '1.5rem 0 1rem' }}>5. Ley aplicable y jurisdicci�n</h2>
      <p>Estas condiciones se rigen por la legislaci�n espa�ola. Para cualquier controversia, las partes se someten a los Juzgados y Tribunales de Jerez de la Frontera.</p>
      
      <p style={{ marginTop: '2rem', fontSize: '0.875rem', color: '#B3B3B3', textAlign: 'center' }}>
        �ltima actualizaci�n: 16 de noviembre de 2025
      </p>
    </div>
  );
}

export default AvisoLegal;


